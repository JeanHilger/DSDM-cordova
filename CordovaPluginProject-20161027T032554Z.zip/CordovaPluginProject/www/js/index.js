/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        var options = { frequency: 100 };
        var watchID = navigator.accelerometer.watchAcceleration(app.onSuccess, app.onError, options);
    },

    onSuccess: function(acceleration) {
        alert( screen.height);
        $("#lbBall").html("X: " + acceleration.x + "<br>" + "Y: " + acceleration.y);
        // alert("X: "+ acceleration.x + "\n" +
            //   "Y: "+ acceleration.y + "\n");
        app.moveBall(acceleration.x, acceleration.y);
    },

    onError: function() {
        alert('onError!');
    },

    moveBall: function(x, y){
        // alert("X: "+x, "Y: "+y);
        var top = (parseInt($("#myBall").css("top").replace("px","")) + ((y - 9.8) * 5)) + "px";
        var left = (parseInt($("#myBall").css("left").replace("px","")) + (x * 5)) + "px";
        console.log("top --> " + top + " |||||| left --> " + left);
        if (left <= screen.width){
            $("#myBall").css("left", left);
        }

        if (top <= screen.height){
            $("#myBall").css("top", top);
        }
    },
};

app.initialize();
